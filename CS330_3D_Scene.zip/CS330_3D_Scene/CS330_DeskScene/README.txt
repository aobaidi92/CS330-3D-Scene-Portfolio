
CS330 Option A - Desk Scene (Starter Project)
=============================================

This solution opens in Visual Studio and expects you already have:
- **GLFW** (headers + libs) 
- **GLAD** (headers + glad.c) 
- **GLM** (headers)

Project is configured to look for libraries in a sibling `Libraries` folder:
- Place this project folder next to your existing `CS330Content\Libraries` from the course
  or create a `Libraries` folder with:
  - `Libraries\glfw\include` and `Libraries\glfw\lib-vc2022` (or lib-vc2019)
  - `Libraries\glad\include\glad` and `Libraries\glad\src\glad.c`
  - `Libraries\glm` (headers only)

If your paths differ, open **Project Properties → C/C++ → Additional Include Directories**
and **Linker → Additional Library Directories** and point them to your local locations.

Build Steps
-----------
1) Open `CS330_OptionA_DeskScene.sln` in Visual Studio (x64, Debug or Release).
2) NuGet/Restore isn't required; just ensure the include & lib paths resolve.
3) Build and Run.

Controls
--------
- WASD: move camera
- Mouse: look around (click the window once to capture the mouse)
- Q/E: move down/up
- ESC: release mouse / close window

Files
-----
- src\MainCode.cpp            → Entry point and scene rendering
- src\Shader.h/.cpp           → Minimal shader loader
- src\Camera.h/.cpp           → FPS-style camera
- shaders\basic.vert/.frag    → Simple Phong lighting + texturing
- assets\Desk_Pic.PNG         → Placeholder texture (your chosen Option A ref image)

Note
----
If you don't have GLM installed, download and place headers under `Libraries\glm` and add that path
to **Additional Include Directories**.
