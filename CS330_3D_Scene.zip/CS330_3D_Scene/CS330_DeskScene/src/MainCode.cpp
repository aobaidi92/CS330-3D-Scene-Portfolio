﻿// MainCode.cpp — CS330 Desk Scene (floor, cube, pyramid, soccer ball)
// Loads shaders & textures from build/Debug/. Mouse look always on.
// Controls: WASD move, Q/E up-down, Scroll zoom, Esc to close.

#include <cstdio>
#include <cstdlib>
#include <string>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define GLM_FORCE_RADIANS
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "stb_image.h"

// ---------- tiny helpers ----------
static std::string readTextFile(const char* path) {
    std::ifstream f(path, std::ios::in | std::ios::binary);
    if (!f) return {};
    std::ostringstream ss; ss << f.rdbuf();
    return ss.str();
}
static GLuint compileShader(GLenum type, const char* src, const char* tag) {
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);
    GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        GLint len = 0; glGetShaderiv(s, GL_INFO_LOG_LENGTH, &len);
        std::string log(len, '\0'); glGetShaderInfoLog(s, len, nullptr, log.data());
        std::cerr << "[Shader compile error] " << tag << "\n" << log << "\n";
        glDeleteShader(s); return 0;
    }
    return s;
}
static GLuint buildProgramFromFiles(const char* vpath, const char* fpath) {
    std::string vsrc = readTextFile(vpath);
    std::string fsrc = readTextFile(fpath);
    if (vsrc.empty()) { std::cerr << "[Shader load error] " << vpath << "\n"; return 0; }
    if (fsrc.empty()) { std::cerr << "[Shader load error] " << fpath << "\n"; return 0; }
    GLuint vs = compileShader(GL_VERTEX_SHADER, vsrc.c_str(), vpath);
    GLuint fs = compileShader(GL_FRAGMENT_SHADER, fsrc.c_str(), fpath);
    if (!vs || !fs) return 0;
    GLuint p = glCreateProgram();
    glAttachShader(p, vs); glAttachShader(p, fs);
    glLinkProgram(p);
    glDeleteShader(vs); glDeleteShader(fs);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) {
        GLint len = 0; glGetProgramiv(p, GL_INFO_LOG_LENGTH, &len);
        std::string log(len, '\0'); glGetProgramInfoLog(p, len, nullptr, log.data());
        std::cerr << "[Program link error]\n" << log << "\n";
        glDeleteProgram(p); return 0;
    }
    return p;
}
static GLuint loadTexture2D(const char* path, bool genMips = true, bool repeat = true) {
    int w, h, n;
    stbi_set_flip_vertically_on_load(1);
    unsigned char* data = stbi_load(path, &w, &h, &n, 0);
    if (!data) { std::cerr << "[Texture load error] " << path << "\n"; return 0; }
    GLenum fmt = (n == 1) ? GL_RED : (n == 3) ? GL_RGB : GL_RGBA;
    GLuint tex; glGenTextures(1, &tex);
    glBindTexture(GL_TEXTURE_2D, tex);
    glTexImage2D(GL_TEXTURE_2D, 0, (fmt == GL_RGBA ? GL_RGBA : GL_RGB), w, h, 0, fmt, GL_UNSIGNED_BYTE, data);
    if (genMips) glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, repeat ? GL_REPEAT : GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, repeat ? GL_REPEAT : GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, genMips ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(data);
    return tex;
}

// ---------- mesh struct ----------
struct MeshGL { GLuint vao = 0, vbo = 0, ebo = 0; GLsizei indexCount = 0; };

// ---------- primitives ----------
static MeshGL makeTiledFloor(float size = 20.f, int tiles = 12) {
    const float s = size, t = (float)tiles;
    float verts[] = {
        // pos            // normal  // uv
        -s, 0, -s,        0,1,0,     0, 0,
         s, 0, -s,        0,1,0,     t, 0,
         s, 0,  s,        0,1,0,     t, t,
        -s, 0,  s,        0,1,0,     0, t
    };
    unsigned int idx[] = { 0,1,2, 0,2,3 };
    MeshGL m; m.indexCount = 6;
    glGenVertexArrays(1, &m.vao);
    glGenBuffers(1, &m.vbo);
    glGenBuffers(1, &m.ebo);
    glBindVertexArray(m.vao);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);
    GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glBindVertexArray(0);
    return m;
}
static MeshGL makeUnitCube() {
    // 24 unique verts (6 faces) with normals + UVs, indexed to 36
    const float v[] = {
        // +Z
        -0.5f,-0.5f, 0.5f,  0,0,1,  0,0,   0.5f,-0.5f, 0.5f,  0,0,1, 1,0,
         0.5f, 0.5f, 0.5f,  0,0,1,  1,1,  -0.5f, 0.5f, 0.5f,  0,0,1, 0,1,
         // -Z
         -0.5f,-0.5f,-0.5f,  0,0,-1, 1,0,   0.5f,-0.5f,-0.5f,  0,0,-1, 0,0,
          0.5f, 0.5f,-0.5f,  0,0,-1, 0,1,  -0.5f, 0.5f,-0.5f,  0,0,-1, 1,1,
          // +X
           0.5f,-0.5f,-0.5f,  1,0,0,  0,0,   0.5f,-0.5f, 0.5f,  1,0,0, 1,0,
           0.5f, 0.5f, 0.5f,  1,0,0,  1,1,   0.5f, 0.5f,-0.5f,  1,0,0, 0,1,
           // -X
           -0.5f,-0.5f,-0.5f, -1,0,0,  1,0,  -0.5f,-0.5f, 0.5f, -1,0,0, 0,0,
           -0.5f, 0.5f, 0.5f, -1,0,0,  0,1,  -0.5f, 0.5f,-0.5f, -1,0,0, 1,1,
           // +Y
           -0.5f, 0.5f,-0.5f,  0,1,0,  0,0,   0.5f, 0.5f,-0.5f,  0,1,0, 1,0,
            0.5f, 0.5f, 0.5f,  0,1,0,  1,1,  -0.5f, 0.5f, 0.5f,  0,1,0, 0,1,
            // -Y
            -0.5f,-0.5f,-0.5f,  0,-1,0, 0,1,   0.5f,-0.5f,-0.5f,  0,-1,0, 1,1,
             0.5f,-0.5f, 0.5f,  0,-1,0, 1,0,  -0.5f,-0.5f, 0.5f,  0,-1,0, 0,0
    };
    const unsigned int idx[] = {
        0,1,2, 0,2,3,      4,5,6, 4,6,7,
        8,9,10, 8,10,11,   12,13,14, 12,14,15,
        16,17,18, 16,18,19, 20,21,22, 20,22,23
    };
    MeshGL m; m.indexCount = 36;
    glGenVertexArrays(1, &m.vao);
    glGenBuffers(1, &m.vbo);
    glGenBuffers(1, &m.ebo);
    glBindVertexArray(m.vao);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(v), v, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);
    GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glBindVertexArray(0);
    return m;
}
// Square pyramid (base on ground, apex up)
static MeshGL makePyramid() {
    // base square + apex
    const float v[] = {
        // pos                // normal (approx)    // uv
        // base (y = 0)
        -0.8f,0.0f,-0.8f,     0,1,0,               0,0,
         0.8f,0.0f,-0.8f,     0,1,0,               1,0,
         0.8f,0.0f, 0.8f,     0,1,0,               1,1,
        -0.8f,0.0f, 0.8f,     0,1,0,               0,1,
        // apex
         0.0f,1.6f, 0.0f,     0,1,0,               0.5f,0.5f
    };
    const unsigned int idx[] = {
        // base
        0,1,2, 0,2,3,
        // sides
        0,1,4, 1,2,4, 2,3,4, 3,0,4
    };
    MeshGL m; m.indexCount = 18;
    glGenVertexArrays(1, &m.vao);
    glGenBuffers(1, &m.vbo);
    glGenBuffers(1, &m.ebo);
    glBindVertexArray(m.vao);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof(v), v, GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(idx), idx, GL_STATIC_DRAW);
    GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glBindVertexArray(0);
    return m;
}
// UV sphere
static MeshGL makeSphere(int stacks = 24, int slices = 48) {
    std::vector<float> v; v.reserve((stacks + 1) * (slices + 1) * 8);
    std::vector<unsigned int> idx; idx.reserve(stacks * slices * 6);
    for (int i = 0; i <= stacks; i++) {
        float phi = i * 3.1415926f / stacks;
        for (int j = 0; j <= slices; j++) {
            float th = j * 2 * 3.1415926f / slices;
            float x = sinf(phi) * cosf(th);
            float y = cosf(phi);
            float z = sinf(phi) * sinf(th);
            v.insert(v.end(), { x,y,z,  x,y,z,  (float)j / slices, (float)i / stacks });
        }
    }
    for (int i = 0; i < stacks; i++) {
        for (int j = 0; j < slices; j++) {
            int a = i * (slices + 1) + j;
            int b = a + slices + 1;
            idx.insert(idx.end(), { (unsigned)a,(unsigned)b,(unsigned)(a + 1),
                                    (unsigned)b,(unsigned)(b + 1),(unsigned)(a + 1) });
        }
    }
    MeshGL m; m.indexCount = (GLsizei)idx.size();
    glGenVertexArrays(1, &m.vao);
    glGenBuffers(1, &m.vbo);
    glGenBuffers(1, &m.ebo);
    glBindVertexArray(m.vao);
    glBindBuffer(GL_ARRAY_BUFFER, m.vbo);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(float), v.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, m.ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * sizeof(unsigned int), idx.data(), GL_STATIC_DRAW);
    GLsizei stride = 8 * sizeof(float);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, stride, (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, stride, (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, stride, (void*)(6 * sizeof(float)));
    glBindVertexArray(0);
    return m;
}

// ---------- camera / input ----------
static int   gWidth = 1280, gHeight = 720;
static float gYaw = -90.f, gPitch = -15.f, gFov = 45.f;
static glm::vec3 gCamPos(0.f, 3.0f, 8.0f);
static double lastX = gWidth * 0.5, lastY = gHeight * 0.5;
static bool  firstMouse = true;
static float gMoveSpeed = 6.0f;
static float gMouseSense = 0.12f;

static void framebuffer_size_callback(GLFWwindow*, int w, int h) {
    gWidth = w; gHeight = h; glViewport(0, 0, w, h);
}
static void cursor_pos_callback(GLFWwindow*, double x, double y) {
    if (firstMouse) { lastX = x; lastY = y; firstMouse = false; }
    float dx = float(x - lastX), dy = float(lastY - y);
    lastX = x; lastY = y;
    gYaw += dx * gMouseSense;
    gPitch += dy * gMouseSense;
    if (gPitch > 89.f) gPitch = 89.f;
    if (gPitch < -89.f) gPitch = -89.f;
}
static void scroll_callback(GLFWwindow*, double, double yoff) {
    gFov -= float(yoff) * 2.f;
    if (gFov < 20.f) gFov = 20.f;
    if (gFov > 75.f) gFov = 75.f;
}
static void do_wasd(GLFWwindow* win, float dt) {
    glm::vec3 front(cosf(glm::radians(gYaw)) * cosf(glm::radians(gPitch)),
        sinf(glm::radians(gPitch)),
        sinf(glm::radians(gYaw)) * cosf(glm::radians(gPitch)));
    front = glm::normalize(front);
    glm::vec3 right = glm::normalize(glm::cross(front, glm::vec3(0, 1, 0)));
    glm::vec3 up = glm::normalize(glm::cross(right, front));
    float v = gMoveSpeed * dt;
    if (glfwGetKey(win, GLFW_KEY_W) == GLFW_PRESS) gCamPos += front * v;
    if (glfwGetKey(win, GLFW_KEY_S) == GLFW_PRESS) gCamPos -= front * v;
    if (glfwGetKey(win, GLFW_KEY_A) == GLFW_PRESS) gCamPos -= right * v;
    if (glfwGetKey(win, GLFW_KEY_D) == GLFW_PRESS) gCamPos += right * v;
    if (glfwGetKey(win, GLFW_KEY_Q) == GLFW_PRESS) gCamPos += up * v;
    if (glfwGetKey(win, GLFW_KEY_E) == GLFW_PRESS) gCamPos -= up * v;
}

// ---------- main ----------
int main() {
    if (!glfwInit()) return -1;
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    GLFWwindow* win = glfwCreateWindow(gWidth, gHeight, "CS330 -- Desk Scene", nullptr, nullptr);
    if (!win) { glfwTerminate(); return -1; }
    glfwMakeContextCurrent(win);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) { std::cerr << "GLAD load failed\n"; return -1; }

    glfwSetFramebufferSizeCallback(win, framebuffer_size_callback);
    glfwSetCursorPosCallback(win, cursor_pos_callback);
    glfwSetScrollCallback(win, scroll_callback);
    glfwSetInputMode(win, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
    glEnable(GL_DEPTH_TEST);

    // Shaders
    GLuint prog = buildProgramFromFiles("build/Debug/basic.vert", "build/Debug/basic.frag");
    if (!prog) { glfwTerminate(); return 0; }

    // Textures (from build/Debug/)
    GLuint texFloor = loadTexture2D("build/Debug/floor.jpg", true, true);
    GLuint texCube = loadTexture2D("build/Debug/cube.jpg", true, true);
    GLuint texPyramid = loadTexture2D("build/Debug/pyramid.jpg", true, true);
    GLuint texSoccer = loadTexture2D("build/Debug/soccer.jpg", true, true);

    // Geometry
    MeshGL floor = makeTiledFloor(20.f, 12);
    MeshGL cube = makeUnitCube();
    MeshGL pyr = makePyramid();
    MeshGL ball = makeSphere(24, 48);

    // Uniforms
    glUseProgram(prog);
    GLint uModel = glGetUniformLocation(prog, "model");
    GLint uView = glGetUniformLocation(prog, "view");
    GLint uProj = glGetUniformLocation(prog, "projection");
    GLint uViewPos = glGetUniformLocation(prog, "viewPos");
    GLint uLPos = glGetUniformLocation(prog, "lightPos");
    GLint uLCol = glGetUniformLocation(prog, "lightColor");
    GLint uOCol = glGetUniformLocation(prog, "objectColor");
    GLint uTex0 = glGetUniformLocation(prog, "tex0");
    glUniform3f(uLPos, 6.f, 7.f, 4.f);
    glUniform3f(uLCol, 1.f, 1.f, 1.f);
    glUniform1i(uTex0, 0);

    double lastT = glfwGetTime();

    while (!glfwWindowShouldClose(win)) {
        double now = glfwGetTime();
        float dt = float(now - lastT);
        lastT = now;

        glfwPollEvents();
        do_wasd(win, dt);

        // Close with Esc
        if (glfwGetKey(win, GLFW_KEY_ESCAPE) == GLFW_PRESS)
            glfwSetWindowShouldClose(win, true);

        glClearColor(0.08f, 0.09f, 0.11f, 1.f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // camera matrices
        glm::vec3 front(cosf(glm::radians(gYaw)) * cosf(glm::radians(gPitch)),
            sinf(glm::radians(gPitch)),
            sinf(glm::radians(gYaw)) * cosf(glm::radians(gPitch)));
        front = glm::normalize(front);
        glm::mat4 V = glm::lookAt(gCamPos, gCamPos + front, glm::vec3(0, 1, 0));
        glm::mat4 P = glm::perspective(glm::radians(gFov), (float)gWidth / (float)gHeight, 0.1f, 300.f);

        glUseProgram(prog);
        glUniformMatrix4fv(uView, 1, GL_FALSE, glm::value_ptr(V));
        glUniformMatrix4fv(uProj, 1, GL_FALSE, glm::value_ptr(P));
        glUniform3fv(uViewPos, 1, glm::value_ptr(gCamPos));
        glActiveTexture(GL_TEXTURE0);

        // ---- Floor (floor.jpg)
        glm::mat4 M(1.f);
        M = glm::rotate(M, glm::radians(-8.f), glm::vec3(1, 0, 0));
        glUniformMatrix4fv(uModel, 1, GL_FALSE, glm::value_ptr(M));
        glUniform3f(uOCol, 1, 1, 1);
        glBindTexture(GL_TEXTURE_2D, texFloor);
        glBindVertexArray(floor.vao);
        glDrawElements(GL_TRIANGLES, floor.indexCount, GL_UNSIGNED_INT, 0);

        // ---- Cube (cube.jpg) — Rubik’s placeholder
        M = glm::mat4(1.f);
        M = glm::translate(M, glm::vec3(0.f, 1.25f, 0.f));
        M = glm::scale(M, glm::vec3(1.5f));
        glUniformMatrix4fv(uModel, 1, GL_FALSE, glm::value_ptr(M));
        glBindTexture(GL_TEXTURE_2D, texCube);
        glBindVertexArray(cube.vao);
        glDrawElements(GL_TRIANGLES, cube.indexCount, GL_UNSIGNED_INT, 0);

        // ---- Pyramid (pyramid.jpg)
        M = glm::mat4(1.f);
        M = glm::translate(M, glm::vec3(3.0f, 0.0f, -2.0f));
        M = glm::scale(M, glm::vec3(1.2f));
        glUniformMatrix4fv(uModel, 1, GL_FALSE, glm::value_ptr(M));
        glBindTexture(GL_TEXTURE_2D, texPyramid);
        glBindVertexArray(pyr.vao);
        glDrawElements(GL_TRIANGLES, pyr.indexCount, GL_UNSIGNED_INT, 0);

        // ---- Soccer ball (soccer.jpg)
        M = glm::mat4(1.f);
        M = glm::translate(M, glm::vec3(-3.0f, 1.0f, -1.0f));
        M = glm::scale(M, glm::vec3(1.0f));
        glUniformMatrix4fv(uModel, 1, GL_FALSE, glm::value_ptr(M));
        glBindTexture(GL_TEXTURE_2D, texSoccer);
        glBindVertexArray(ball.vao);
        glDrawElements(GL_TRIANGLES, ball.indexCount, GL_UNSIGNED_INT, 0);

        glBindVertexArray(0);
        glfwSwapBuffers(win);
    }

    // cleanup
    auto del = [](MeshGL& m) { if (m.ebo) glDeleteBuffers(1, &m.ebo); if (m.vbo) glDeleteBuffers(1, &m.vbo); if (m.vao) glDeleteVertexArrays(1, &m.vao); };
    del(floor); del(cube); del(pyr); del(ball);
    glDeleteTextures(1, &texFloor);
    glDeleteTextures(1, &texCube);
    glDeleteTextures(1, &texPyramid);
    glDeleteTextures(1, &texSoccer);
    glDeleteProgram(prog);
    glfwTerminate();
    return 0;
}
